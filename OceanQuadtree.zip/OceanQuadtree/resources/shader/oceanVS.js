export const oceanVS = `


	vec3 orthogonal(vec3 v) {
		return normalize(abs(v.x) > abs(v.z) ? vec3(-v.y, v.x, 0.0) : vec3(0.0, -v.z, v.y));
	}

	//-----------------


	void main(){

		idx = float(vindex);

		ivec2 texSize = textureSize(vertexTexture, 0);
   	float texWidth = float(texSize.x);
   	float texHeight = float(texSize.y);
   	int colIdx = int(floor(idx / texWidth));
   	int rowIdx = int(mod(idx, texHeight));
		vec3 positionD = texelFetch(vertexTexture, ivec2(rowIdx, colIdx), 0).rgb;
		vec3 normalD = texelFetch(normalTexture, ivec2(rowIdx, colIdx), 0).rgb;
	
		vec3 wpos = (modelMatrix * vec4(positionD, 1.0)).xyz + cameraPosition;
		float displacement = 3.0 * pnoise( 0.1 * wpos + vec3( 0.5 * time ), vec3( 3.0 ) );
		vec3 displacedPosition = positionD + normalD * displacement;
  
  
		vec3 displacedEdges = FixEdgesAndSkirts(vindex, texWidth, texHeight);
  
		if(dot(displacedEdges, displacedEdges) > 0.){
			displacedPosition = displacedEdges;
		}
		
		vCoords = coords;
		vNormal = normalize(normalD);
		gl_Position = projectionMatrix * modelViewMatrix * vec4(displacedPosition, 1.0);	
	}
`;