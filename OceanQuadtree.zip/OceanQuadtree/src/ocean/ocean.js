import {THREE} from '../three-defs.js';
import {entity} from '../entity.js';
import {ocean_constants} from './ocean-constants.js';
import {ocean_builder_threaded} from './ocean-builder-threaded.js';
import {quadtree} from './quadtree.js';
import {utils} from './utils.js';

//modular shaders
import { headerVS } from "../../resources/shader/headerVS.js";
import { headerFS } from "../../resources/shader/headerFS.js";
import { perlinNoise } from "../../resources/shader/perlinNoise.js";
import { FixEdgesAndSkirts } from "../../resources/shader/fixEdgesAndSkirts.js";
import { oceanVS } from "../../resources/shader/oceanVS.js";
import { oceanFS } from "../../resources/shader/oceanFS.js";



export const ocean = (() => {


	class OceanChunkManager extends entity.Component {
		constructor(params) {
			super();    	
			this.Init(params);
		}

		Init(params) {
			this.params_ = params;
			this.builder_ = new ocean_builder_threaded.OceanChunkRebuilder_Threaded();

			this.LoadTextures(params);
			this.InitOcean(params);
		}
     
		//****************************Material*****************************
		LoadTextures(params) {

			var uniform = {
				vertexTexture: {value: null},
				normalTexture: {value: null},
				sunPosition: {value: params.sunpos},
				color: {value: new THREE.Vector3(20/255, 50/255, 120/255)},
				time: {value: 0}, 			
	 			width: {value: 0},
	 			resolution: {value: 0},
	 			offset: {value: new THREE.Vector3()},
	 			wMatrix: {value: new THREE.Matrix4()},
	 			neighbours: {value: new THREE.Vector4()},
			}


			this.material_ = new THREE.RawShaderMaterial({
				glslVersion: THREE.GLSL3,
				uniforms: uniform,
				vertexShader:  
					headerVS + '\n' +
					perlinNoise + '\n' +
					FixEdgesAndSkirts + '\n' +
					oceanVS,
				fragmentShader:
					headerFS + '\n' +
					perlinNoise + '\n' +				
					oceanFS,
				side: THREE.DoubleSide,
				wireframe: params.wireframe,
			});
      
    }
		//****************************************************************


		InitOcean(params) {
			this.group = new THREE.Group();
			params.scene.add(this.group);
			this.chunks_ = {};
		}


		CreateOceanChunk(group, groupTransform, offset, width, neighbours, resolution) {
			const params = {
				group: group,
				transform: groupTransform,
				material: this.material_.clone(),
				width: width,
				offset: offset,
				resolution: resolution,
				neighbours: neighbours,
			};

			return this.builder_.AllocateChunk(params);
		}


		Update(_) {
			const cameraPosition = this.params_.camera.position.clone();

			this.builder_.Update();
      	if (!this.builder_.Busy) {
				for (let k in this.chunks_) {
          	this.chunks_[k].chunk.Show();
        	}
        	this.UpdateVisibleChunks_Quadtree_(cameraPosition);       
      	}

      	for (let k in this.chunks_) {
        	this.chunks_[k].chunk.Update(this.params_.camera.position);
        	this.chunks_[k].chunk.mesh_.material.uniforms.time.value = this.params_.clock.getElapsedTime();
        	this.chunks_[k].chunk.mesh_.material.uniformsNeedUpdate = true;
      	}
      	for (let c of this.builder_.old_) {
        	c.chunk.Update(this.params_.camera.position);
      	}
		}//end Update


		UpdateVisibleChunks_Quadtree_(cameraPosition) {
        
			function _Key(c) {
				return c.position[0] + '/' + c.position[1] + ' [' + c.size + ']';
			}

			const q = new quadtree.Root({
				size: ocean_constants.OCEAN_SIZE,
				min_node_size: ocean_constants.QT_OCEAN_MIN_CELL_SIZE,
				max_node_size: ocean_constants.QT_OCEAN_MAX_CELL_SIZE,
			});
			q.Insert(cameraPosition);
			q.BuildNeighbours();

			const sides = q.GetChildren();

			let newOceanChunks = {};
			const center = new THREE.Vector3();
			const dimensions = new THREE.Vector3();

			const _Child = (c) => {
				c.bounds.getCenter(center);
				c.bounds.getSize(dimensions);

				const child = {
					group: this.group,
					transform: sides.transform,
					position: [center.x, center.y, center.z],
					bounds: c.bounds,
					size: dimensions.x,
					neighbours: c.neighbours.map(n => n.size.x / c.size.x),
					neighboursOriginal: c.neighbours,
				};
				return child;
			};


				for (let c of sides.children) {
					const child = _Child(c);
					const k = _Key(child);
					
					const left = c.neighbours[0].GetClosestChildrenSharingEdge(c.GetLeftEdgeMidpoint());
					const top = c.neighbours[1].GetClosestChildrenSharingEdge(c.GetTopEdgeMidpoint());
					const right = c.neighbours[2].GetClosestChildrenSharingEdge(c.GetRightEdgeMidpoint());
					const bottom = c.neighbours[3].GetClosestChildrenSharingEdge(c.GetBottomEdgeMidpoint());

					child.neighbourKeys = [...left, ...top, ...right, ...bottom].map(n => _Key(_Child(n)));
					child.debug = [left, top, right, bottom];

					newOceanChunks[k] = child;
					
				}


			const allChunks = newOceanChunks;
			const intersection = utils.DictIntersection(this.chunks_, newOceanChunks);
			const difference = utils.DictDifference(newOceanChunks, this.chunks_);
			const recycle = Object.values(utils.DictDifference(this.chunks_, newOceanChunks));

			const allChunksLeft = utils.DictIntersection(newOceanChunks, recycle);

			if (0) {
				const partialRebuilds = {};

				for (let k in difference) {
					for (let n of difference[k].neighbourKeys) {
						if (n in this.chunks_) {
							partialRebuilds[n] = newOceanChunks[n];
						}
					}
				}
				
				for (let k in partialRebuilds) {
					if (k in intersection) {
						recycle.push(this.chunks_[k]);
						delete intersection[k];
						difference[k] = allChunks[k];
					}
				}
			}

			this.builder_.RetireChunks(recycle);

			newOceanChunks = intersection;
			

			for (let k in difference) {
				const [xp, yp, zp] = difference[k].position;

				const offset = new THREE.Vector3(xp, yp, zp);
				
				newOceanChunks[k] = {
					position: [xp, zp],
					chunk: this.CreateOceanChunk(
						difference[k].group, difference[k].transform,
						offset, difference[k].size, difference[k].neighbours,
						ocean_constants.QT_OCEAN_MIN_CELL_RESOLUTION),
				};
        
				for (let n of difference[k].neighbourKeys) {
					if (n in this.chunks_) {					
						const neighbours = new THREE.Vector4().fromArray(allChunks[n].neighbours);					
						this.chunks_[n].chunk.mesh_.material.uniforms.neighbours.value = neighbours;
						this.chunks_[n].chunk.mesh_.material.uniformsNeedUpdate = true;
					}
				}							
			}

			this.chunks_ = newOceanChunks;
		}
 
	}//end class



return {
	OceanChunkManager: OceanChunkManager,
}

})();