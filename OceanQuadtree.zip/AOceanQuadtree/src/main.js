import {THREE} from './three-defs.js';
import {entity} from './entity.js';
import {threejs_component} from './threejs-component.js';
import {entity_manager} from './entity-manager.js';
import {BasicController} from './basic-controller.js'; 
import {ocean} from './ocean/ocean.js';



class Main {

	constructor(){
	}

	Initialize() {   
		this.entityManager_ = new entity_manager.EntityManager();
		this.OnGameStarted();
	}

	OnGameStarted() {
		this.clock_ = new THREE.Clock();
		this.LoadControllers();
		this.previousRAF = null;
		this.RAF();
	}


  LoadControllers() {
  
		const threejs = new entity.Entity();
    	threejs.AddComponent(new threejs_component.ThreeJSController());
    	this.entityManager_.Add(threejs, 'threejs');

    	this.scene_ = threejs.GetComponent('ThreeJSController').scene_;
    	this.camera_ = threejs.GetComponent('ThreeJSController').camera_;
    	this.threejs_ = threejs.GetComponent('ThreeJSController');

		const basicParams = {
			scene: this.scene_,
			camera: this.camera_,
		};

		//------------------------------------------------------------------------------------------------------------------------------------------

		this.camera_.position.set(0, 1000, 0);
		this.player = new BasicController(basicParams);


		//***********************************************************************************
		//***********************Multithreading-Quadtree-Ocean****************************
		const ocean_ = new entity.Entity();
		ocean_.AddComponent(
			new ocean.OceanChunkManager({
				camera: this.camera_,
				scene: this.scene_,
				threejs: this.threejs_,
				sunpos: new THREE.Vector3(100000, 0, 100000),
				clock: this.clock_,
				wireframe: true,
     	})
     );
		this.entityManager_.Add(ocean_, 'ocean');				
		//**********************************************************************************
		//**********************************************************************************


		var light = new THREE.AmbientLight(0xffffff, 1); 
		this.scene_.add(light);

	}
	

	RAF() {
	
    requestAnimationFrame((t) => {
      if (this.previousRAF === null) {
        this.previousRAF = t;
      } else {
        this.Step(t - this.previousRAF);
        this.threejs_.Render();
        this.previousRAF = t;
      }

      setTimeout(() => {
        this.RAF();
      }, 1);
    });
  }
  
  
  Step(timeElapsed) { 
    const timeElapsedS = Math.min(1.0 / 30.0, timeElapsed * 0.001);
    this.player.Update(0.01);//hack, just a fast implementation
    this.entityManager_.Update(timeElapsedS, 0);
  }

}


export {Main}