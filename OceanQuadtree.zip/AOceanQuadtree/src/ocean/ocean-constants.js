import {THREE} from '../three-defs.js';


export const ocean_constants = (function() {
  return {

		QT_OCEAN_MIN_CELL_SIZE: 16,	
		QT_OCEAN_MIN_CELL_RESOLUTION: 24,
		OCEAN_SIZE: 100000,

  }
})();