import {THREE} from '../three-defs.js';



export const ocean_chunk = (function() {

  class OceanChunk {
    constructor(params) {
      this.params_ = params;
      this.Init(params);
    }
    
    Destroy() {
      this.params_.group.remove(this.mesh_);
    }

    Hide() {
      this.mesh_.visible = false;
    }

    Show() {
      this.mesh_.visible = true;
    }

    Init(params) {
      this.geometry_ = new THREE.BufferGeometry();
      this.mesh_ = new THREE.Mesh(this.geometry_, params.material);
      this.mesh_.castShadow = false;
      this.mesh_.receiveShadow = true;
   	 this.mesh_.frustumCulled = false;
      this.params_.group.add(this.mesh_);
      this.Reinit(params);     
    }

    Update() {

    }

    Reinit(params) {
      this.params_ = params;
      this.mesh_.position.set(0, 0, 0);
    }

		SetWireframe(b) {
			this.mesh_.material.wireframe = b;
		}


		GenerateVertexTexture(g){
  
			let vertAmount = g.attributes.position.count;
			let texWidth = Math.ceil(Math.sqrt(vertAmount));
			let texHeight = Math.ceil(vertAmount / texWidth);
  
			let data = new Float32Array(texWidth * texHeight * 4);
  
			for(let i = 0; i < vertAmount; i++){
				data[i * 4 + 0] = g.attributes.position.getX(i);
				data[i * 4 + 1] = g.attributes.position.getY(i);
				data[i * 4 + 2] = g.attributes.position.getZ(i);
				data[i * 4 + 3] = 0;
			}
  
			let dataTexture = new THREE.DataTexture(
				data, 
				texWidth, 
				texHeight, 
				THREE.RGBAFormat, 
				THREE.FloatType
			);
			dataTexture.needsUpdate = true;
  
			return dataTexture;
		}


		GenerateNormalTexture(g){
  
			let vertAmount = g.attributes.normal.count;
			let texWidth = Math.ceil(Math.sqrt(vertAmount));
			let texHeight = Math.ceil(vertAmount / texWidth);
  
			let data = new Float32Array(texWidth * texHeight * 4);
  
			for(let i = 0; i < vertAmount; i++){
				data[i * 4 + 0] = g.attributes.normal.getX(i);
				data[i * 4 + 1] = g.attributes.normal.getY(i);
				data[i * 4 + 2] = g.attributes.normal.getZ(i);
				data[i * 4 + 3] = 0;
			}
  
			let dataTexture = new THREE.DataTexture(
				data, 
				texWidth, 
				texHeight, 
				THREE.RGBAFormat, 
				THREE.FloatType
			);
			dataTexture.needsUpdate = true;
  
			return dataTexture;
		}


		RebuildMeshFromData(data) {
			this.geometry_.setAttribute('position', new THREE.Float32BufferAttribute(data.positions, 3));
			this.geometry_.setAttribute('normal', new THREE.Float32BufferAttribute(data.normals, 3));
			this.geometry_.setAttribute('coords', new THREE.Float32BufferAttribute(data.coords, 3));
			this.geometry_.setAttribute('vindex', new THREE.Int32BufferAttribute(data.vindices, 1));
			this.geometry_.setIndex(new THREE.BufferAttribute(data.indices, 1));
      
			this.geometry_.attributes.position.needsUpdate = true;
			this.geometry_.attributes.normal.needsUpdate = true;
			this.geometry_.attributes.coords.needsUpdate = true;
			this.geometry_.attributes.vindex.needsUpdate = true;
  
			this.vertexDataTexture = this.GenerateVertexTexture(this.geometry_);
			this.normalDataTexture = this.GenerateNormalTexture(this.geometry_);
 
			this.mesh_.material.uniforms.wMatrix.value = data.worldMatrix;
			this.mesh_.material.uniforms.resolution.value = data.resolution;
			this.mesh_.material.uniforms.offset.value = data.offset;
			this.mesh_.material.uniforms.width.value = data.width;
			this.mesh_.material.uniforms.neighbours.value = new THREE.Vector4().fromArray(data.neighbours);
			this.mesh_.material.uniforms.vertexTexture.value = this.vertexDataTexture;
			this.mesh_.material.uniforms.normalTexture.value = this.normalDataTexture;
			this.mesh_.material.uniformsNeedUpdate = true;
 
		}

  }

  return {
    OceanChunk: OceanChunk
  }
})();