export const oceanFS = `



	// returns intensity of diffuse reflection
	vec3 diffuseLighting(vec3 N, vec3 L){
		// calculation as for Lambertian reflection
		float diffuseTerm = clamp(dot(N, L), 0., 1.) ;
		//return u_matDiffuseReflectance * u_lightDiffuseIntensity * diffuseTerm;
		return  vec3(1.)*diffuseTerm;
	}

	// returns intensity of specular reflection
	vec3 specularLighting(vec3 N, vec3 L, vec3 V){
		float specularTerm = 0.;

		// calculate specular reflection only if
		// the surface is oriented to the light source
		if(dot(N, L) > 0.){
			// half vector
		//	vec3 R = reflect(-L, N);
			vec3 H = normalize(L + V);
			specularTerm = pow(dot(N, H), 64.);
	//		float specAngle = max(dot(R, V), 0.0);
	//		float specular = pow(specAngle, 64.);
		}
		//return u_matSpecularReflectance * u_lightSpecularIntensity * specularTerm;
		return vec3(1.)*specularTerm*0.75;
		//return vec3(1.)*specular*10.;
	}





	vec4 _CalculateLighting(vec3 lightDirection, vec3 lightColour, vec3 worldSpaceNormal, vec3 planetNormal, vec3 viewDirection) {
		float diffuse = saturate(dot(worldSpaceNormal, lightDirection));
		
		//float lambertian = max(dot(lightDirection, planetNormal), 0.0);
		vec3 diffuseLight = diffuseLighting(planetNormal, lightDirection);
		//vec3 reflectDir = reflect(-lightDirection, worldSpaceNormal); 
		
		
		vec3 specLight = specularLighting(worldSpaceNormal,  lightDirection,  viewDirection);
		
		
		return vec4(4.*diffuseLight + specLight, 1.0);

	}


	vec4 _ComputeLighting(vec3 worldSpaceNormal, vec3 sunDir, vec3 viewDirection, vec3 planetNormal) {
		vec4 lighting;
  
		lighting += _CalculateLighting(sunDir, 1.0 * vec3(1.0, 1.0, 1.0), worldSpaceNormal, planetNormal, viewDirection);
  
		return lighting;
	}

	//****************

	vec3 orthogonal(vec3 v) {
		return normalize(abs(v.x) > abs(v.z) ? vec3(-v.y, v.x, 0.0) : vec3(0.0, -v.z, v.y));
	}

	//****************


void main() {

	vec3 worldPosition = vCoords;
	vec3 eyeDirection = normalize(worldPosition - cameraPosition);
	vec3 sunDir = normalize(vec3(1., 0., -0.15));//normalize(worldPosition - sunPosition);
	
	/*
	vec3 worldSpaceNormal = vNormal;
	vec3 planetNormal = wNormal;

	vec4 lighting = _ComputeLighting(worldSpaceNormal, -sunDir, -eyeDirection, planetNormal);
  
	
	vec3 diffuseLight = diffuseLighting(planetNormal, -sunDir);	
	vec3 specLight = specularLighting(worldSpaceNormal, -sunDir, -eyeDirection);
	
	
	vec3 finalColour = color * diffuseLight + specLight;
*/


	//out_FragColor = vec4(finalColour, 1.);


		//Calculate surface Normal

		float ds = 1.0;	//hardcoded, need a better solution!
		vec3 tangent = orthogonal(vNormal);
		vec3 bitangent = normalize(cross(vNormal, tangent));
		vec3 neighbour1 = vCoords + tangent * ds;
		vec3 neighbour2 = vCoords + bitangent * ds;

		float displacement0 = 3.0 * pnoise( 0.1 * vCoords + vec3( 0.5 * time ), vec3( 3.0 ) );
		float displacement1 = 3.0 * pnoise( 0.1 * neighbour1 + vec3( 0.5 * time ), vec3( 3.0 ) );
		float displacement2 = 3.0 * pnoise( 0.1 * neighbour2 + vec3( 0.5 * time ), vec3( 3.0 ) );


		vec3 displacedPosition = vCoords + vNormal * displacement0;
		vec3 displacedNeighbour1 = neighbour1 + vNormal * displacement1;
		vec3 displacedNeighbour2 = neighbour2 + vNormal * displacement2;


		vec3 displacedTangent = displacedNeighbour1 - displacedPosition;
		vec3 displacedBitangent = displacedNeighbour2 - displacedPosition;
	
		vec3 displacedNormal = normalize(cross(displacedTangent, displacedBitangent));





		float ldotn = dot(displacedNormal, -sunDir);

		//out_FragColor = vec4(normalize(worldPosition), 1.);
		//out_FragColor = vec4(ldotn * vec3(0.2, 0.5, 1.) + 0.75 * vec3(0.05, 0.1, 0.4), 1.);
		//out_FragColor = vec4(vNormal, 1.);
		out_FragColor = vec4(displacedNormal * vec3(1.), 1.);

		//out_FragColor = normalize(neighbours) * (1. - normalize(neighbours).a/2.);
	
}
`;



//***************************************************************************************